  <div class="col-lg-3">
      <div class="card client-card">
          <div class="card-body text-center">
              <img src="{{ URL::asset('assets/images/users/'.$image.'')}}" alt="user" class="rounded-circle thumb-xl">
              <h5 class=" client-name">Wendy Keen</h5>
              <span class="text-muted mr-3"><i class="dripicons-location mr-2 text-info"></i>New York, USA</span>
              <span class="text-muted"><i class="dripicons-phone mr-2 text-info"></i>+1 123 456 789</span>
              <p class="text-muted text-center mt-3">Contrary to popular belief, Lorem Ipsum is not simply random text.</p>
              <button type="button" class="btn btn-sm btn-gradient-secondary">Project</button>
              <button type="button" class="btn btn-sm btn-gradient-primary">Message</button>
          </div>
          <!--end card-body-->
      </div>
      <!--end card-->
  </div>
  <!--end col-->