<div class="col-lg-3">
                                                    <div class="card dash-data-card text-center">
                                                        <div class="card-body"> 
                                                            <div class="icon-info mb-3">
                                                                <i class="{{$iClass}}"></i>
                                                            </div>
                                                            <h3 class="text-dark">{{$count}}</h3>
                                                            <h6 class="font-14 text-dark">{{$title}}</h6>                                                                                                                            
                                                        </div><!--end card-body--> 
                                                    </div><!--end card-->   
                                                </div><!-- end col-->
                                                