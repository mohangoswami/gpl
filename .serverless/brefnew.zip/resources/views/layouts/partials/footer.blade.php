 <footer class="footer text-center text-sm-left">
     &copy; {{ date('Y') }} - {{ date('Y', strtotime('+1 year')) }} Subodham.com <span class="text-muted d-none d-sm-inline-block float-right">Crafted with <i class="mdi mdi-heart text-danger"></i> by Mohan Goswami</span>
 </footer>