  <!-- leftbar-tab-menu -->
        <div class="leftbar-tab-menu">
            <div class="main-icon-menu">
                <a href="#" class="logo logo-metrica d-block text-center">
                    <span>
                        <img src="{{ URL::asset('assets/images/gpl_logo2.png')}}" alt="logo-small" class="rounded-circle logo-sm">
                    </span>
                </a>
               
                <div class="pro-metrica-end">
                  
                </div>
            </div><!--end main-icon-menu-->

            <div class="main-menu-inner">
                <!-- LOGO -->
                <div class="topbar-left">
                    <a href="/analytics/analytics-index" class="logo">
                        <span>
                            <img src="{{ URL::asset('assets/images/gpl_logo2.png')}}" alt="logo-large" class="logo-lg logo-dark">
                            <img src="{{ URL::asset('assets/images/gpl_logo2.png')}}" alt="logo-large" class="logo-lg logo-light">
                        </span>
                    </a>
                </div>
                <!--end logo-->
                
            </div><!-- end main-menu-inner-->
        </div>
        <!-- end leftbar-tab-menu-->