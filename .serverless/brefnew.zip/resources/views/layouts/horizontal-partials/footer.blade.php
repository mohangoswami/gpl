 <footer class="footer text-center text-sm-left">
    <div class="boxed-footer">
       &copy; {{ date('Y') }} Metrica <span class="text-muted d-none d-sm-inline-block float-right">Crafted with <i class="mdi mdi-heart text-danger"></i> by Themesbrand</span>
    </div>
 </footer>
 <!--end footer-->