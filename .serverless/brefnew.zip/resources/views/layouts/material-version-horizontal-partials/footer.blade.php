
                <footer class="footer text-center text-sm-left">
                    &copy; {{  date('Y') }} - {{  date('Y', strtotime('+1 year')) }} Metrica <span class="text-muted d-none d-sm-inline-block float-right">Crafted with <i class="mdi mdi-heart text-danger"></i> by Themesbrand</span>
                </footer><!--end footer-->